

<div class="navbar">
           <div class="navbar-inner">
               <div class="container-fluid">
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
             
							<div class="nav-collapse collapse">
							<ul class="nav" id="footer_nav">
			<li class="divider-vertical"></li>
		<li><a href="../index.php"><i class="icon-home"></i>&nbsp;Home</a></li>
			<li class="divider-vertical"></li>
		<li><a href="../about.php"><i class="icon-info-sign"></i>&nbsp;About</a></li>
			<li class="divider-vertical"></li>
		<li><a href="../calendar_of_events.php"><i class="icon-phone"></i>&nbsp;Contact Us</a></li>
			<li class="divider-vertical"></li>
	
	</ul>
							</div>
                   <!--/.nav-collapse -->
               </div>
           </div>
</div>

	