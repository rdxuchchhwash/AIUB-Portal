<div class="pull-right">
		<footer>
           <p>Programmed by mango </p>
        <footer>
</div>