<center>
		<footer>
		
		<p>AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH <a href="http://www.aiub.edu"> <br />AIUB</a></p>
		</footer>
</center>

