				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/New folder/Logo.png">
						</div>	
												
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>AMERICAN INTERNATIONAL UNIVERSITY <br /> <br /> BANGLADESH (AIUB) </p>
												<br /> <br /> <p>WHERE LEADERS ARE CREATED</p>
												
								</div>		
						</div>		
				</div>